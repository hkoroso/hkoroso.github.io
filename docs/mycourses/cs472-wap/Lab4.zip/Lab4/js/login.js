document.getElementById("submitBtn").addEventListener("click", () => {
    console.log("Email: " + document.getElementById("exampleInputEmail1").value + "\n" +
    "Password: " + document.getElementById("exampleInputPassword1").value + "\n" + 
    "URL: " + document.getElementById("exampleInputUrl1").value);
});